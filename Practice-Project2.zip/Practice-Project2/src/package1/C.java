package package1;

public class C {

		public int c;
}
